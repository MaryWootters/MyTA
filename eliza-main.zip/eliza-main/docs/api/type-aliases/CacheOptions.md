[@ai16z/eliza v0.1.5-alpha.5](../index.md) / CacheOptions

# Type Alias: CacheOptions

> **CacheOptions**: `object`

## Type declaration

### expires?

> `optional` **expires**: `number`

## Defined in

[packages/core/src/types.ts:985](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L985)
