[@ai16z/eliza v0.1.5-alpha.5](../index.md) / KnowledgeItem

# Type Alias: KnowledgeItem

> **KnowledgeItem**: `object`

## Type declaration

### id

> **id**: [`UUID`](UUID.md)

### content

> **content**: [`Content`](../interfaces/Content.md)

## Defined in

[packages/core/src/types.ts:1218](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1218)
