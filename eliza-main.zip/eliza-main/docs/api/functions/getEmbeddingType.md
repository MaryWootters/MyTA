[@ai16z/eliza v0.1.5-alpha.5](../index.md) / getEmbeddingType

# Function: getEmbeddingType()

> **getEmbeddingType**(`runtime`): `"local"` \| `"remote"`

## Parameters

• **runtime**: [`IAgentRuntime`](../interfaces/IAgentRuntime.md)

## Returns

`"local"` \| `"remote"`

## Defined in

[packages/core/src/embedding.ts:99](https://github.com/ai16z/eliza/blob/main/packages/core/src/embedding.ts#L99)
