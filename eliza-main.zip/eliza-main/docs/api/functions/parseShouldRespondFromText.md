[@ai16z/eliza v0.1.5-alpha.5](../index.md) / parseShouldRespondFromText

# Function: parseShouldRespondFromText()

> **parseShouldRespondFromText**(`text`): `"RESPOND"` \| `"IGNORE"` \| `"STOP"`

## Parameters

• **text**: `string`

## Returns

`"RESPOND"` \| `"IGNORE"` \| `"STOP"`

## Defined in

[packages/core/src/parsing.ts:14](https://github.com/ai16z/eliza/blob/main/packages/core/src/parsing.ts#L14)
