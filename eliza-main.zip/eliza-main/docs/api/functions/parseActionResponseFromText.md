[@ai16z/eliza v0.1.5-alpha.5](../index.md) / parseActionResponseFromText

# Function: parseActionResponseFromText()

> **parseActionResponseFromText**(`text`): `object`

## Parameters

• **text**: `string`

## Returns

`object`

### actions

> **actions**: [`ActionResponse`](../interfaces/ActionResponse.md)

## Defined in

[packages/core/src/parsing.ts:153](https://github.com/ai16z/eliza/blob/main/packages/core/src/parsing.ts#L153)
