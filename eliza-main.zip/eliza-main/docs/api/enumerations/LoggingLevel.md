[@ai16z/eliza v0.1.5-alpha.5](../index.md) / LoggingLevel

# Enumeration: LoggingLevel

## Enumeration Members

### DEBUG

> **DEBUG**: `"debug"`

#### Defined in

[packages/core/src/types.ts:1213](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1213)

***

### VERBOSE

> **VERBOSE**: `"verbose"`

#### Defined in

[packages/core/src/types.ts:1214](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1214)

***

### NONE

> **NONE**: `"none"`

#### Defined in

[packages/core/src/types.ts:1215](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1215)
