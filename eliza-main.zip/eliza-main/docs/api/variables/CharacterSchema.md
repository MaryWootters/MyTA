[@ai16z/eliza v0.1.5-alpha.5](../index.md) / CharacterSchema

# Variable: CharacterSchema

> `const` **CharacterSchema**: `any`

Main Character schema

## Defined in

[packages/core/src/environment.ts:66](https://github.com/ai16z/eliza/blob/main/packages/core/src/environment.ts#L66)
