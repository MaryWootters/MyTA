[@ai16z/eliza v0.1.5-alpha.5](../index.md) / defaultCharacter

# Variable: defaultCharacter

> `const` **defaultCharacter**: [`Character`](../type-aliases/Character.md)

## Defined in

[packages/core/src/defaultCharacter.ts:3](https://github.com/ai16z/eliza/blob/main/packages/core/src/defaultCharacter.ts#L3)
