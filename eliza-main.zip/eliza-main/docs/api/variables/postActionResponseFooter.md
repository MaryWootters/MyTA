[@ai16z/eliza v0.1.5-alpha.5](../index.md) / postActionResponseFooter

# Variable: postActionResponseFooter

> `const` **postActionResponseFooter**: `"Choose any combination of [LIKE], [RETWEET], [QUOTE], and [REPLY] that are appropriate. Each action must be on its own line. Your response must only include the chosen actions."`

## Defined in

[packages/core/src/parsing.ts:151](https://github.com/ai16z/eliza/blob/main/packages/core/src/parsing.ts#L151)
