[@ai16z/eliza v0.1.5-alpha.5](../index.md) / ActionResponse

# Interface: ActionResponse

## Properties

### like

> **like**: `boolean`

#### Defined in

[packages/core/src/types.ts:1224](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1224)

***

### retweet

> **retweet**: `boolean`

#### Defined in

[packages/core/src/types.ts:1225](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1225)

***

### quote?

> `optional` **quote**: `boolean`

#### Defined in

[packages/core/src/types.ts:1226](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1226)

***

### reply?

> `optional` **reply**: `boolean`

#### Defined in

[packages/core/src/types.ts:1227](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1227)
