[@ai16z/eliza v0.1.5-alpha.5](../index.md) / IAgentConfig

# Interface: IAgentConfig

## Indexable

 \[`key`: `string`\]: `string`
